// Node.js regression test for sanitizeImport in app/src/main/assets/index.html
const fs = require('fs');
const html = fs.readFileSync(__dirname + '/app/src/main/assets/index.html', 'utf8');
const start = html.indexOf('function sanitizeImport(parsed){');
const end = html.indexOf('\nasync function applyImportedData(obj){', start);
if (start < 0 || end < 0) throw new Error('sanitizeImport function not found');
const fn = html.slice(start, end);
function validISO(v) {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const [y,m,d] = v.split('-').map(Number);
  const dt = new Date(y,m-1,d);
  return y >= 1900 && y <= 2200 && dt.getFullYear()===y && dt.getMonth()===m-1 && dt.getDate()===d;
}
const sanitizeImport = new Function('validISO', `${fn}; return sanitizeImport;`)(validISO);
const types = ['income','expense','loan_in','loan_out','transfer'];
const transactions = types.map((type,i)=>({
  id:i+1,type,amount:1000+i,desc:'test '+type,date:'2026-11-25',
  fp:'fp-'+type,bank:'بلو بانک',src:'sms',cat:'other',transferRef:'tr-'+i
}));
const result = sanitizeImport({transactions,installments:[],paidInstallments:[],smsFingerprints:['fp-income']});
if (result.data.transactions.length !== 5) throw new Error('not all supported transaction types restored');
for (let i=0;i<types.length;i++) {
  const row=result.data.transactions[i];
  if(row.type!==types[i] || row.fp!=='fp-'+types[i] || row.bank!=='بلو بانک' || row.src!=='sms' || row.cat!=='other' || row.transferRef!=='tr-'+i)
    throw new Error('metadata lost for '+types[i]);
}
const invalid = sanitizeImport({transactions:[{type:'unknown',amount:50,date:'2026-11-25'},{type:'income',amount:-1,date:'2026-11-25'}],installments:[]});
if(invalid.data.transactions.length!==0 || invalid.report.dropped!==2) throw new Error('invalid rows were not rejected');
console.log('PASS: five transaction types and metadata preserved; invalid rows rejected.');
