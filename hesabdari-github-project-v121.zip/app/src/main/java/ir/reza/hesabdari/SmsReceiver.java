package ir.reza.hesabdari;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Runs when a bank SMS arrives, even if the app is closed. It shows a notification;
// the app adds the transaction the next time it is opened (the same rules as the page).
public class SmsReceiver extends BroadcastReceiver {

    static final String CHANNEL = "bank_sms";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !"android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) return;
        Bundle b = intent.getExtras();
        if (b == null) return;
        Object[] pdus = (Object[]) b.get("pdus");
        if (pdus == null) return;
        String fmt = b.getString("format");
        StringBuilder sb = new StringBuilder();
        for (Object p : pdus) {
            SmsMessage m = Build.VERSION.SDK_INT >= 23
                    ? SmsMessage.createFromPdu((byte[]) p, fmt)
                    : SmsMessage.createFromPdu((byte[]) p);
            if (m != null && m.getMessageBody() != null) sb.append(m.getMessageBody());
        }
        String body = digits(sb.toString());
        if (!body.contains("ریال") || !body.contains("موجودی")) return;

        Matcher am = Pattern.compile("([\\d,٬]+)\\s*ریال").matcher(body);
        if (!am.find()) return;
        long rial = toNumber(am.group(1));
        long toman = Math.round(rial / 10.0);
        Matcher bm = Pattern.compile("موجودی\\s*:?\\s*([\\d,٬]+)").matcher(body);
        long balanceToman = bm.find() ? Math.round(toNumber(bm.group(1)) / 10.0) : -1;

        boolean expense = Pattern.compile("پرید|برداشت|خرید|کسر|پرداخت").matcher(body).find();
        boolean income = !expense && Pattern.compile("نشست|واریز|دریافت|به حساب شما").matcher(body).find();
        if (!expense && !income) return;

        String kind = expense ? "خرج" : "درآمد";
        String amount = NumberFormat.getInstance(Locale.US).format(toman);
        String text = kind + ": " + amount + " تومان";
        if (balanceToman >= 0) {
            text += "  |  موجودی: " + NumberFormat.getInstance(Locale.US).format(balanceToman) + " تومان";
        }

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "تراکنش‌های پیامک بانک",
                    NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("اعلان تراکنش جدید از پیامک بانک");
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 77, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder nb = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL)
                : new Notification.Builder(context);
        nb.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("تراکنش جدید از پیامک بانک")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setContentIntent(pi);
        nm.notify((int) (System.currentTimeMillis() % 100000), nb.build());
    }

    static String digits(String t) {
        StringBuilder out = new StringBuilder();
        String fa = "۰۱۲۳۴۵۶۷۸۹";
        String ar = "٠١٢٣٤٥٦٧٨٩";
        for (char c : t.toCharArray()) {
            int i = fa.indexOf(c);
            int j = ar.indexOf(c);
            if (i >= 0) out.append((char) ('0' + i));
            else if (j >= 0) out.append((char) ('0' + j));
            else out.append(c);
        }
        return out.toString();
    }

    static long toNumber(String s) {
        try {
            return Long.parseLong(s.replace(",", "").replace("٬", ""));
        } catch (Exception e) {
            return 0;
        }
    }
}
