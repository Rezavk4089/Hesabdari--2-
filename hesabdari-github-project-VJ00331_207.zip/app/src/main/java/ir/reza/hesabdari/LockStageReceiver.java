package ir.reza.hesabdari;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

// a few seconds after a bank SMS, the lock-screen card moves from the deposit line to the day balance
public class LockStageReceiver extends BroadcastReceiver {

    private static final int REQUEST = 4401;
    private static final long DELAY_MS = 4000;

    static void schedule(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(ctx, LockStageReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, REQUEST, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + DELAY_MS, pi);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences p = context.getSharedPreferences(MainActivity.BAL_PREFS, Context.MODE_PRIVATE);
        MainActivity.showBalanceNotification(context, p.getLong("balance", 0));
    }
}
