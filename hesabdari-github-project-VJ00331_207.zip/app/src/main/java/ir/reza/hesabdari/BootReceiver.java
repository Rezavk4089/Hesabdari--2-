package ir.reza.hesabdari;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

// after the phone restarts, the saved reminders are scheduled again
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            MainActivity.rescheduleSaved(context);
            android.content.SharedPreferences p =
                    context.getSharedPreferences(MainActivity.BAL_PREFS, Context.MODE_PRIVATE);
            if (p.contains("balance")) {
                MainActivity.showBalanceNotification(context, p.getLong("balance", 0));
            }
        }
    }
}
