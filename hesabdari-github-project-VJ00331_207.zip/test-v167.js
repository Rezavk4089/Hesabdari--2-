const fs=require('fs'),assert=require('assert');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const script=html.match(/<script\b[^>]*>([\s\S]*?)<\/script>/i)[1];
const extract=(name,next)=>{const a=script.indexOf('function '+name+'(');const b=script.indexOf('function '+next+'(',a);if(a<0||b<0)throw Error('missing '+name);return script.slice(a,b)};
const txCode=extract('txTotals','renderTopSummary');
const balStart=script.indexOf('function balanceAt('),balEnd=script.indexOf('function syncLockBalance(',balStart);
const catsStart=script.indexOf('let TX_CATS='),catsEnd=script.indexOf('function saveOpeningBalance(',catsStart);
const walletStart=script.indexOf('let WALLET_PERIOD='),walletEnd=script.indexOf('function setTxType(t){',walletStart);
const els={};for(const id of ['walletCurrentBalance','walletPeriodLabel','walletIncome','walletExpense','walletNet','walletEndBalance','walletLoanIn','walletLoanOut','walletTxCount','walletCategories','walletTransactions'])els[id]={textContent:'',innerHTML:''};
const buttons=['day','week','month','year'].map(x=>({dataset:{walletPeriod:x},classList:{toggle(){}}}));
global.document={getElementById:id=>els[id]||null,querySelectorAll:s=>s==='[data-wallet-period]'?buttons:[]};
global.data={openingBalance:500000,openingBalanceDate:'2026-11-25',customCategories:[{id:'custom_1',name:'قرض دادن'}],transactions:[
{id:1,date:'2026-11-26',type:'income',amount:100000,desc:'حقوق'},
{id:2,date:'2026-11-26',type:'expense',amount:25000,desc:'خرید',cat:'daily'},
{id:3,date:'2026-11-25',type:'loan_in',amount:50000,desc:'وام'},
{id:4,date:'2026-11-24',type:'loan_out',amount:10000,desc:'قسط قبل از مبنا'},
{id:5,date:'2026-12-01',type:'income',amount:900000,desc:'آینده'},
{id:6,date:'2026-11-26',type:'expense',amount:7000,desc:'قرض',cat:'custom_1'}]};
global.todayISO=()=> '2026-11-26';global.isoFromMs=ms=>{const d=new Date(ms);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
global.toJalali=(y,m,d)=>[1405,8,5];global.isoFromJalali=(y,m,d)=>`2026-${String(m===8?11:m===1?3:2).padStart(2,'0')}-${String(d).padStart(2,'0')}`;global.jalaliMonthLength=()=>30;
global.JMONTHS=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];global.faDigits=x=>String(x);global.fmtMoney=x=>String(Math.round(x))+' تومان';global.esc=x=>String(x);global.jalaliLabel=x=>x;
global.validISO=v=>/^\d{4}-\d{2}-\d{2}$/.test(v);require('vm').runInThisContext(txCode);
eval(script.slice(balStart,balEnd));
eval(script.slice(catsStart,catsEnd));
eval(script.slice(walletStart,walletEnd));
ensureTxCategories();assert.equal(catLabel('custom_1'),'قرض دادن');
assert.equal(balanceAt('2026-11-26'),618000,'opening balance plus transactions since base date');
assert.equal(balanceAt('2026-11-24'),0,'before opening balance date is unknown/zero');
for(const p of ['day','week','month','year']){setWalletPeriod(p);assert.ok(els.walletPeriodLabel.textContent,'period label '+p);}
setWalletPeriod('day');assert.equal(els.walletCurrentBalance.textContent,'618000 تومان');assert.equal(els.walletIncome.textContent,'100000 تومان');assert.equal(els.walletExpense.textContent,'32000 تومان');assert.equal(els.walletEndBalance.textContent,'618000 تومان');assert.equal(els.walletTxCount.textContent,'3');assert.ok(!els.walletTransactions.innerHTML.includes('آینده'));
console.log('PASS: dynamic user category label; opening balance baseline; historical transaction cutoff; current balance; daily income/expense; future transaction exclusion; day/week/month/year view rendering.');
