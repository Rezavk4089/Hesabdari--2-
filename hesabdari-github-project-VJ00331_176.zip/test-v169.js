// Tests for the multi-account model (v169). Loads the real functions from index.html.
const fs=require('fs'),assert=require('assert');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const script=html.match(/<script\b[^>]*>([\s\S]*?)<\/script>/i)[1];
const els={};for(const id of ['walletCurrentBalance','walletBalLabel','walletPeriodLabel','walletIncome','walletExpense','walletNet','walletEndBalance','walletLoanIn','walletLoanOut','walletTxCount','walletCategories','walletTransactions'])els[id]={textContent:'',innerHTML:''};
const buttons=['day','week','month','year'].map(x=>({dataset:{walletPeriod:x},classList:{toggle(){}}}));
global.document={getElementById:id=>els[id]||null,querySelectorAll:s=>s==='[data-wallet-period]'?buttons:[]};
global.todayISO=()=>'2026-11-26';global.isoFromMs=ms=>{const d=new Date(ms);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
global.toJalali=(y,m,d)=>[1405,8,5];global.isoFromJalali=(y,m,d)=>`2026-${String(m===8?11:m===1?3:2).padStart(2,'0')}-${String(d).padStart(2,'0')}`;global.jalaliMonthLength=()=>30;
global.JMONTHS=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];global.faDigits=x=>String(x);global.fmtMoney=x=>String(Math.round(x))+' تومان';global.faMoneyDigits=x=>String(Math.round(x));global.esc=x=>String(x);global.jalaliLabel=x=>x;
global.validISO=v=>/^\d{4}-\d{2}-\d{2}$/.test(v);
global.catLabel=k=>k;
const bal=script.slice(script.indexOf('function balanceAt('),script.indexOf('function syncLockBalance('));
const cats=script.slice(script.indexOf('let TX_CATS='),script.indexOf('function saveOpeningBalance('));
const wal=script.slice(script.indexOf('let WALLET_PERIOD='),script.indexOf('function setTxType(t){'));
const txc=script.slice(script.indexOf('function txTotals('),script.indexOf('function renderTopSummary('));
require('vm').runInThisContext(txc);
eval(bal);eval(cats);eval(wal);

// Scenario A (single account, old data): same numbers as before
global.data={openingBalance:500000,openingBalanceDate:'2026-11-25',transactions:[
{id:1,date:'2026-11-26',type:'income',amount:100000},
{id:2,date:'2026-11-26',type:'expense',amount:25000,cat:'daily'},
{id:3,date:'2026-11-25',type:'loan_in',amount:50000},
{id:4,date:'2026-11-24',type:'loan_out',amount:10000},
{id:5,date:'2026-12-01',type:'income',amount:900000},
{id:6,date:'2026-11-26',type:'expense',amount:7000,cat:'other'}]};
assert.equal(balanceAt('2026-11-26'),618000,'single account balance unchanged');
setWalletPeriod('day');
assert.equal(els.walletIncome.textContent,'100000 تومان');
assert.equal(els.walletExpense.textContent,'32000 تومان');

ensureTxCategories();
// Scenario B (three accounts): main card, cash wallet, transfer between them
global.data={openingBalance:500000,openingBalanceDate:'2026-11-25',
accounts:[{id:'main',name:'کارت اصلی',role:'main'},{id:'cash',name:'نقد در کیف',role:'cash',ob:0,obd:'2026-11-25'}],
transactions:[
{id:1,date:'2026-11-26',type:'income',amount:100000,acc:'main'},
{id:2,date:'2026-11-26',type:'expense',amount:25000,acc:'main',cat:'daily'},
{id:3,date:'2026-11-26',type:'transfer',amount:200000,acc:'main',toAcc:'cash'},
{id:4,date:'2026-11-26',type:'income',amount:30000,acc:'cash'},
{id:5,date:'2026-11-26',type:'transfer',amount:5000}]};
assert.equal(balanceAt('2026-11-26','main'),375000,'main: 500000 + 100000 - 25000 - 200000 transfer out');
assert.equal(balanceAt('2026-11-26','cash'),230000,'cash: 200000 transfer in + 30000 cash income');
setWalletAcc('main');
assert.equal(els.walletCurrentBalance.textContent,'375000 تومان');
assert.equal(els.walletIncome.textContent,'100000 تومان','transfer is not income');
assert.equal(els.walletExpense.textContent,'25000 تومان','transfer is not expense');
assert.equal(els.walletTxCount.textContent,'4','main list: income, expense, transfer out, legacy SMS transfer');
setWalletAcc('cash');
assert.equal(els.walletCurrentBalance.textContent,'230000 تومان');
assert.equal(els.walletIncome.textContent,'30000 تومان','cash income not merged with the card');
assert.equal(els.walletExpense.textContent,'0 تومان');
setWalletAcc('__all__');
assert.equal(els.walletIncome.textContent,'130000 تومان');
assert.equal(els.walletExpense.textContent,'25000 تومان');
assert.equal(els.walletEndBalance.textContent,'605000 تومان','sum of all accounts stays equal after transfers');
assert.equal(els.walletTxCount.textContent,'5');
console.log('PASS v169: single-account numbers unchanged; per-account balances; transfers excluded from income/expense; per-account wallet totals; all-accounts total.');
