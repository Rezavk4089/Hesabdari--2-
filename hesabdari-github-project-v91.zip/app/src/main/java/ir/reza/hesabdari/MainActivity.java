package ir.reza.hesabdari;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.content.ContentResolver;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    public static final String CHANNEL_ID = "installments";
    private static final String PREFS = "reminders";
    private static final String KEY_IDS = "ids";
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 1002;
    private static final int SMS_REQUEST = 1003;
    private static final int BACKUP_FOLDER_REQUEST = 1004;
    private static final String BACKUP_PREFS = "backup";
    private static final String BACKUP_PREFIX = "hesabdari-auto-";
    private static final int KEEP_AUTO_BACKUPS = 5;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    // a picked file that arrived after the activity was recreated (the picker can close it)
    private String pendingKind = null;
    private String pendingContent = null;
    private int pendingTries = 0;
    private final Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();

        webView = new WebView(this);
        setContentView(webView);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        webView.addJavascriptInterface(new NativeSaver(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                deliverPending();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                boolean image = false;
                String[] types = params.getAcceptTypes();
                if (types != null) {
                    for (String t : types) {
                        if (t != null && t.startsWith("image")) image = true;
                    }
                }
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(image ? "image/*" : "*/*");
                try {
                    startActivityForResult(Intent.createChooser(intent, "انتخاب فایل"), FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState != null) {
            // the activity was recreated: restore the page instead of starting from scratch
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "یادآوری قسط و بدهی", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("اعلان سررسید قسط و بدهی");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BACKUP_FOLDER_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri tree = data.getData();
                try {
                    getContentResolver().takePersistableUriPermission(tree,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                } catch (Exception ignored) {
                }
                getSharedPreferences(BACKUP_PREFS, MODE_PRIVATE).edit().putString("tree", tree.toString()).apply();
                Toast.makeText(this, "پوشه‌ی بکاپ انتخاب شد", Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (requestCode != FILE_CHOOSER_REQUEST) return;

        Uri uri = (resultCode == RESULT_OK && data != null) ? data.getData() : null;

        if (filePathCallback != null) {
            // normal case: the page is still waiting for the answer
            Uri[] results = uri != null ? new Uri[]{uri} : null;
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }
        // the page was recreated while the picker was open: hand the file to the page directly
        if (uri == null) return;
        String type = getContentResolver().getType(uri);
        if (type != null && type.startsWith("image")) {
            String dataUrl = imageToDataUrl(uri);
            if (dataUrl != null) {
                pendingKind = "image";
                pendingContent = dataUrl;
                pendingTries = 0;
                deliverPending();
            }
        } else {
            String text = readText(uri);
            if (text != null) {
                pendingKind = "json";
                pendingContent = text;
                pendingTries = 0;
                deliverPending();
            }
        }
    }

    private void deliverPending() {
        if (pendingContent == null || webView == null) return;
        final String js = "(window.nativeFilePicked ? (window.nativeFilePicked(" + JSONObject.quote(pendingKind)
                + "," + JSONObject.quote(pendingContent) + "), 'ok') : 'no')";
        webView.evaluateJavascript(js, value -> {
            if (value != null && value.contains("ok")) {
                pendingContent = null;
                pendingKind = null;
            } else if (pendingTries < 15) {
                pendingTries++;
                handler.postDelayed(this::deliverPending, 700);
            }
        });
    }

    private String imageToDataUrl(Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            int max = Math.max(bounds.outWidth, bounds.outHeight);
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = Math.max(1, max / 1280);
            Bitmap bmp;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                bmp = BitmapFactory.decodeStream(in, null, opts);
            }
            if (bmp == null) return null;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.JPEG, 85, bos);
            bmp.recycle();
            return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return null;
        }
    }

    private String readText(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) return null;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private PendingIntent reminderIntent(String id, String title, String text, boolean create) {
        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.putExtra("title", title);
        intent.putExtra("text", text);
        intent.putExtra("id", id.hashCode());
        int flags = PendingIntent.FLAG_IMMUTABLE | (create ? PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_NO_CREATE);
        return PendingIntent.getBroadcast(this, id.hashCode(), intent, flags);
    }

    public class NativeSaver {

        @JavascriptInterface
        public void chooseBackupFolder() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try {
                    startActivityForResult(i, BACKUP_FOLDER_REQUEST);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "انتخاب پوشه در این گوشی ممکن نیست", Toast.LENGTH_LONG).show();
                }
            });
        }

        // Writes one JSON file into the chosen folder and keeps only the newest five automatic files.
        // Returns "ok", "nofolder" or "error".
        @JavascriptInterface
        public String autoBackup(String filename, String json) {
            String treeStr = getSharedPreferences(BACKUP_PREFS, MODE_PRIVATE).getString("tree", null);
            if (treeStr == null) return "nofolder";
            try {
                Uri tree = Uri.parse(treeStr);
                ContentResolver cr = getContentResolver();
                String parentId = DocumentsContract.getTreeDocumentId(tree);
                Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, parentId);
                Uri doc = DocumentsContract.createDocument(cr, parent, "application/json", filename);
                if (doc == null) return "error";
                try (OutputStream out = cr.openOutputStream(doc)) {
                    if (out == null) return "error";
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                }
                // collect our automatic backups and remove the oldest ones
                Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
                List<String[]> items = new ArrayList<>();
                try (Cursor c = cr.query(children, new String[]{
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
                    if (c != null) {
                        while (c.moveToNext()) {
                            String id = c.getString(0);
                            String name = c.getString(1);
                            if (name != null && name.startsWith(BACKUP_PREFIX) && name.endsWith(".json")) {
                                items.add(new String[]{id, name});
                            }
                        }
                    }
                }
                // names contain the date and time, so sorting by name sorts by age
                Collections.sort(items, new Comparator<String[]>() {
                    @Override
                    public int compare(String[] a, String[] b) {
                        return a[1].compareTo(b[1]);
                    }
                });
                while (items.size() > KEEP_AUTO_BACKUPS) {
                    String[] oldest = items.remove(0);
                    Uri old = DocumentsContract.buildDocumentUriUsingTree(tree, oldest[0]);
                    DocumentsContract.deleteDocument(cr, old);
                }
                return "ok";
            } catch (Exception e) {
                return "error";
            }
        }

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(() -> finish());
        }

        @JavascriptInterface
        public boolean saveFile(String filename, String mimeType, String content) {
            try {
                byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
                String safeName = filename.replaceAll("[^A-Za-z0-9._-]", "_");

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) return false;
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) return false;
                        out.write(bytes);
                    }
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists()) dir.mkdirs();
                    try (FileOutputStream out = new FileOutputStream(new File(dir, safeName))) {
                        out.write(bytes);
                    }
                }

                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "فایل پشتیبان در پوشه Download ذخیره شد", Toast.LENGTH_LONG).show());
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, NOTIFICATION_PERMISSION_REQUEST);
                }
            });
        }

        @JavascriptInterface
        public void scheduleNotification(String id, String title, String text, long triggerAtMillis) {
            try {
                AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                if (am == null) return;
                PendingIntent pi = reminderIntent(id, title, text, true);
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);

                SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
                Set<String> ids = new HashSet<>(prefs.getStringSet(KEY_IDS, new HashSet<String>()));
                ids.add(id);
                prefs.edit().putStringSet(KEY_IDS, ids).apply();
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void cancelAllNotifications() {
            try {
                AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
                Set<String> ids = prefs.getStringSet(KEY_IDS, new HashSet<String>());
                if (am != null) {
                    for (String id : ids) {
                        PendingIntent pi = reminderIntent(id, "", "", false);
                        if (pi != null) {
                            am.cancel(pi);
                            pi.cancel();
                        }
                    }
                }
                prefs.edit().remove(KEY_IDS).apply();
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public boolean hasSmsPermission() {
            return checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void requestSmsPermission() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.READ_SMS}, SMS_REQUEST);
                }
            });
        }

        // Returns only messages that look like bank balance messages (contain "ریال" and "موجودی").
        // Nothing is sent to the internet; the text is only handed to the page in memory.
        @JavascriptInterface
        public String readBankSmsJson(int maxCount) {
            JSONArray arr = new JSONArray();
            Cursor c = null;
            try {
                c = getContentResolver().query(Uri.parse("content://sms/inbox"),
                        new String[]{"body", "date"}, null, null, "date DESC");
                if (c == null) return "[]";
                int n = 0;
                while (c.moveToNext() && n < maxCount) {
                    String body = c.getString(0);
                    long date = c.getLong(1);
                    if (body != null && body.contains("ریال") && body.contains("موجودی")) {
                        JSONObject o = new JSONObject();
                        o.put("body", body);
                        o.put("date", date);
                        arr.put(o);
                        n++;
                    }
                }
            } catch (Exception e) {
                return "[]";
            } finally {
                if (c != null) c.close();
            }
            return arr.toString();
        }
    }
}
