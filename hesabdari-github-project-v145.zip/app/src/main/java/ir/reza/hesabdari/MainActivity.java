package ir.reza.hesabdari;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.DocumentsContract;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentInfo;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.content.ContentResolver;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    public static final String CHANNEL_ID = "installments";
    private static final String PREFS = "reminders";
    private static final String KEY_IDS = "ids";
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 1002;
    private static final int SMS_REQUEST = 1003;
    private static final int BACKUP_FOLDER_REQUEST = 1004;
    private static final int BACKUP_SAVE_REQUEST = 1005;
    private String pendingBackupJson = null;
    private WebView printWebView = null;
    private static final String BACKUP_PREFS = "backup";
    private static final String BACKUP_PREFIX = "hesabdari-auto-";
    private static final int KEEP_AUTO_BACKUPS = 5;
    private static final int ALL_PERMS_REQUEST = 1010;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    // a picked file that arrived after the activity was recreated (the picker can close it)
    private String pendingKind = null;
    private String pendingContent = null;
    private int pendingTries = 0;
    private final Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();

        webView = new WebView(this);
        setContentView(webView);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        webView.addJavascriptInterface(new NativeSaver(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                deliverPending();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                boolean image = false;
                String[] types = params.getAcceptTypes();
                if (types != null) {
                    for (String t : types) {
                        if (t != null && t.startsWith("image")) image = true;
                    }
                }
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(image ? "image/*" : "*/*");
                try {
                    startActivityForResult(Intent.createChooser(intent, "انتخاب فایل"), FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        requestAllPermissionsOnce();

        if (savedInstanceState != null) {
            // the activity was recreated: restore the page instead of starting from scratch
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "یادآوری قسط و بدهی", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("اعلان سررسید قسط و بدهی");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BACKUP_SAVE_REQUEST) {
            String json = pendingBackupJson != null ? pendingBackupJson : readPendingBackup();
            pendingBackupJson = null;
            new File(getCacheDir(), "pending_backup.json").delete();
            if (resultCode == RESULT_OK && data != null && data.getData() != null && json != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new Exception("no stream");
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                    callBackupResult(true, "بکاپ در مسیر انتخاب‌شده ذخیره شد");
                } catch (Exception e) {
                    callBackupResult(false, "ذخیره‌ی بکاپ انجام نشد");
                }
            } else {
                callBackupResult(false, "ذخیره‌ی بکاپ لغو شد");
            }
            return;
        }
        if (requestCode == BACKUP_FOLDER_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri tree = data.getData();
                try {
                    getContentResolver().takePersistableUriPermission(tree,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                } catch (Exception ignored) {
                }
                getSharedPreferences(BACKUP_PREFS, MODE_PRIVATE).edit().putString("tree", tree.toString()).apply();
                Toast.makeText(this, "پوشه‌ی بکاپ انتخاب شد", Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (requestCode != FILE_CHOOSER_REQUEST) return;

        Uri uri = (resultCode == RESULT_OK && data != null) ? data.getData() : null;

        if (filePathCallback != null) {
            // normal case: the page is still waiting for the answer
            Uri[] results = uri != null ? new Uri[]{uri} : null;
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }
        // the page was recreated while the picker was open: hand the file to the page directly
        if (uri == null) return;
        String type = getContentResolver().getType(uri);
        if (type != null && type.startsWith("image")) {
            String dataUrl = imageToDataUrl(uri);
            if (dataUrl != null) {
                pendingKind = "image";
                pendingContent = dataUrl;
                pendingTries = 0;
                deliverPending();
            }
        } else {
            String text = readText(uri);
            if (text != null) {
                pendingKind = "json";
                pendingContent = text;
                pendingTries = 0;
                deliverPending();
            }
        }
    }

    private void deliverPending() {
        if (pendingContent == null || webView == null) return;
        final String js = "(window.nativeFilePicked ? (window.nativeFilePicked(" + JSONObject.quote(pendingKind)
                + "," + JSONObject.quote(pendingContent) + "), 'ok') : 'no')";
        webView.evaluateJavascript(js, value -> {
            if (value != null && value.contains("ok")) {
                pendingContent = null;
                pendingKind = null;
            } else if (pendingTries < 15) {
                pendingTries++;
                handler.postDelayed(this::deliverPending, 700);
            }
        });
    }

    private String imageToDataUrl(Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            int max = Math.max(bounds.outWidth, bounds.outHeight);
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = Math.max(1, max / 1280);
            Bitmap bmp;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                bmp = BitmapFactory.decodeStream(in, null, opts);
            }
            if (bmp == null) return null;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.JPEG, 85, bos);
            bmp.recycle();
            return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return null;
        }
    }

    private String readText(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) return null;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }


    private static final String SCHEDULED_KEY = "saved";

    static void scheduleAlarm(Context ctx, String id, String title, String text, long at) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent intent = new Intent(ctx, ReminderReceiver.class);
        intent.putExtra("title", title);
        intent.putExtra("text", text);
        intent.putExtra("id", id.hashCode());
        PendingIntent pi = PendingIntent.getBroadcast(ctx, id.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    static void rememberAlarm(Context ctx, String id, String title, String text, long at) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, MODE_PRIVATE_COMPAT);
        try {
            JSONArray arr = new JSONArray(prefs.getString(SCHEDULED_KEY, "[]"));
            JSONArray next = new JSONArray();
            for (int k = 0; k < arr.length(); k++) {
                JSONObject o = arr.getJSONObject(k);
                if (!id.equals(o.optString("id"))) next.put(o);
            }
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("title", title); o.put("text", text); o.put("at", at);
            next.put(o);
            prefs.edit().putString(SCHEDULED_KEY, next.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    static void rescheduleSaved(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, MODE_PRIVATE_COMPAT);
        long now = System.currentTimeMillis();
        try {
            JSONArray arr = new JSONArray(prefs.getString(SCHEDULED_KEY, "[]"));
            JSONArray keep = new JSONArray();
            for (int k = 0; k < arr.length(); k++) {
                JSONObject o = arr.getJSONObject(k);
                long at = o.optLong("at");
                if (at > now) {
                    scheduleAlarm(ctx, o.optString("id"), o.optString("title"), o.optString("text"), at);
                    keep.put(o);
                }
            }
            prefs.edit().putString(SCHEDULED_KEY, keep.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    static final int MODE_PRIVATE_COMPAT = Context.MODE_PRIVATE;


    // The first time the app opens, ask for everything it needs in one go.
    private void requestAllPermissionsOnce() {
        SharedPreferences p = getSharedPreferences("setup", MODE_PRIVATE);
        if (p.getBoolean("perm_v1", false)) return;
        p.edit().putBoolean("perm_v1", true).apply();
        requestMissingPermissions();
    }

    private void requestMissingPermissions() {
        List<String> need = new ArrayList<>();
        String[] wanted = {"android.permission.READ_SMS", "android.permission.RECEIVE_SMS"};
        for (String w : wanted) {
            if (checkSelfPermission(w) != PackageManager.PERMISSION_GRANTED) need.add(w);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            need.add("android.permission.POST_NOTIFICATIONS");
        }
        if (need.isEmpty()) {
            openExactIfNeeded();
        } else {
            requestPermissions(need.toArray(new String[0]), ALL_PERMS_REQUEST);
        }
    }

    // Exact alarms (for on-time reminders) are a special permission: the user grants it on a settings screen.
    private void openExactIfNeeded() {
        if (Build.VERSION.SDK_INT < 31) return;
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (am == null || am.canScheduleExactAlarms()) return;
        SharedPreferences p = getSharedPreferences("setup", MODE_PRIVATE);
        if (p.getBoolean("exact_opened", false)) return;
        p.edit().putBoolean("exact_opened", true).apply();
        Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
        i.setData(Uri.parse("package:" + getPackageName()));
        try {
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == ALL_PERMS_REQUEST) openExactIfNeeded();
    }

    private void toastOnUi(String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    private String readPendingBackup() {
        try (FileInputStream in = new FileInputStream(new File(getCacheDir(), "pending_backup.json"))) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    private void callBackupResult(boolean ok, String msg) {
        if (webView == null) return;
        webView.evaluateJavascript("window.nativeBackupResult && window.nativeBackupResult("
                + ok + "," + JSONObject.quote(msg) + ")", null);
    }

    private PendingIntent reminderIntent(String id, String title, String text, boolean create) {
        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.putExtra("title", title);
        intent.putExtra("text", text);
        intent.putExtra("id", id.hashCode());
        int flags = PendingIntent.FLAG_IMMUTABLE | (create ? PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_NO_CREATE);
        return PendingIntent.getBroadcast(this, id.hashCode(), intent, flags);
    }

    public class NativeSaver {

        @JavascriptInterface
        public String autoBackup(String filename, String json) {
            String treeStr = getSharedPreferences(BACKUP_PREFS, MODE_PRIVATE).getString("tree", null);
            if (treeStr == null) return "nofolder";
            try {
                Uri tree = Uri.parse(treeStr);
                ContentResolver cr = getContentResolver();
                String parentId = DocumentsContract.getTreeDocumentId(tree);
                Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, parentId);
                Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);

                // our automatic files, oldest first: {document id, name, last modified}
                List<String[]> items = new ArrayList<>();
                try (Cursor c = cr.query(children, new String[]{
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_LAST_MODIFIED}, null, null, null)) {
                    if (c != null) {
                        while (c.moveToNext()) {
                            String id = c.getString(0);
                            String name = c.getString(1);
                            String mod = c.getString(2);
                            if (name != null && name.startsWith(BACKUP_PREFIX) && name.endsWith(".json")) {
                                items.add(new String[]{id, name, mod == null ? "0" : mod});
                            }
                        }
                    }
                }
                Collections.sort(items, new Comparator<String[]>() {
                    @Override
                    public int compare(String[] a, String[] b) {
                        long x = 0, y = 0;
                        try { x = Long.parseLong(a[2]); } catch (Exception ignored) { }
                        try { y = Long.parseLong(b[2]); } catch (Exception ignored) { }
                        return Long.compare(x, y);
                    }
                });

                // only two automatic files are kept: the newest, and one older that gets replaced
                while (items.size() > 2) {
                    String[] old = items.remove(0);
                    DocumentsContract.deleteDocument(cr, DocumentsContract.buildDocumentUriUsingTree(tree, old[0]));
                }

                if (items.size() < 2) {
                    Uri doc = DocumentsContract.createDocument(cr, parent, "application/json", filename);
                    if (doc == null) return "error";
                    try (OutputStream out = cr.openOutputStream(doc, "wt")) {
                        if (out == null) return "error";
                        out.write(json.getBytes(StandardCharsets.UTF_8));
                    }
                } else {
                    // overwrite the older file, then give it the new name (date, weekday and time)
                    Uri old = DocumentsContract.buildDocumentUriUsingTree(tree, items.get(0)[0]);
                    try (OutputStream out = cr.openOutputStream(old, "wt")) {
                        if (out == null) return "error";
                        out.write(json.getBytes(StandardCharsets.UTF_8));
                    }
                    DocumentsContract.renameDocument(cr, old, filename);
                }
                return "ok";
            } catch (Exception e) {
                return "error";
            }
        }

        // opens the system "save as" window every time, so the user picks the place
        @JavascriptInterface
        public void saveBackupAs(String filename, String mimeType, String content) {
            pendingBackupJson = content;
            try (FileOutputStream o = new FileOutputStream(new File(getCacheDir(), "pending_backup.json"))) {
                o.write(content.getBytes(StandardCharsets.UTF_8));
            } catch (Exception ignored) {
            }
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, filename);
                try {
                    startActivityForResult(i, BACKUP_SAVE_REQUEST);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    callBackupResult(false, "باز کردن پنجره‌ی ذخیره ممکن نیست");
                }
            });
        }

        // the report page is printed by the system: the user chooses Save as PDF and the folder
        @JavascriptInterface
        public void printReportPdf(String html, String filename) {
            runOnUiThread(() -> {
                printWebView = new WebView(MainActivity.this);
                printWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        if (pm == null) return;
                        PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(filename);
                        pm.print(filename, adapter,
                                new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                    }
                });
                printWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            });
        }

        // the report is printed by the system: the user chooses "Save as PDF" and the folder
        @JavascriptInterface
        public void savePdfDirect(String html, String filename) {
            printReportPdf(html, filename);
        }

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(() -> finish());
        }

        @JavascriptInterface
        public boolean saveFile(String filename, String mimeType, String content) {
            try {
                byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
                String safeName = filename.replaceAll("[^A-Za-z0-9._-]", "_");

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) return false;
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) return false;
                        out.write(bytes);
                    }
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists()) dir.mkdirs();
                    try (FileOutputStream out = new FileOutputStream(new File(dir, safeName))) {
                        out.write(bytes);
                    }
                }

                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "فایل پشتیبان در پوشه Download ذخیره شد", Toast.LENGTH_LONG).show());
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, NOTIFICATION_PERMISSION_REQUEST);
                }
            });
        }





        @JavascriptInterface
        public void scheduleNotification(String id, String title, String text, long triggerAtMillis) {
            try {
                if (triggerAtMillis <= System.currentTimeMillis()) return;
                scheduleAlarm(MainActivity.this, id, title, text, triggerAtMillis);
                rememberAlarm(MainActivity.this, id, title, text, triggerAtMillis);
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void cancelAllNotifications() {
            try {
                AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
                JSONArray arr = new JSONArray(prefs.getString(SCHEDULED_KEY, "[]"));
                if (am != null) {
                    for (int k = 0; k < arr.length(); k++) {
                        String id = arr.getJSONObject(k).optString("id");
                        Intent intent = new Intent(MainActivity.this, ReminderReceiver.class);
                        PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, id.hashCode(), intent,
                                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                        if (pi != null) {
                            am.cancel(pi);
                            pi.cancel();
                        }
                    }
                }
                prefs.edit().putString(SCHEDULED_KEY, "[]").apply();
            } catch (Exception ignored) {
            }
        }

        // "ok", "no_permission", "no_exact", or "disabled"
        @JavascriptInterface
        public String notificationsStatus() {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                return "no_permission";
            }
            if (nm != null && Build.VERSION.SDK_INT >= 24 && !nm.areNotificationsEnabled()) {
                return "disabled";
            }
            if (Build.VERSION.SDK_INT >= 31) {
                AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                if (am != null && !am.canScheduleExactAlarms()) return "no_exact";
            }
            return "ok";
        }

        @JavascriptInterface
        public void openExactAlarmSettings() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 31) {
                    Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    try {
                        startActivity(i);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public boolean hasSmsPermission() {
            return checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void requestSmsPermission() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS}, SMS_REQUEST);
                }
            });
        }

        // Returns only messages that look like bank balance messages (contain "ریال" and "موجودی").
        // Nothing is sent to the internet; the text is only handed to the page in memory.
        // every sender that sent a bank message (text with ریال and موجودی)
        @JavascriptInterface
        public String listBankSenders() {
            java.util.LinkedHashMap<String, JSONObject> map = new java.util.LinkedHashMap<>();
            Cursor c = null;
            try {
                c = getContentResolver().query(Uri.parse("content://sms/inbox"),
                        new String[]{"address", "body"}, null, null, "date DESC");
                if (c == null) return "[]";
                while (c.moveToNext()) {
                    String addr = c.getString(0);
                    String body = c.getString(1);
                    if (addr == null || body == null || !body.contains("ریال") || !body.contains("موجودی")) continue;
                    JSONObject o = map.get(addr);
                    if (o == null) {
                        o = new JSONObject();
                        o.put("address", addr);
                        o.put("count", 0);
                        o.put("sample", body.length() > 70 ? body.substring(0, 70) : body);
                        map.put(addr, o);
                    }
                    o.put("count", o.optInt("count") + 1);
                }
            } catch (Exception e) {
                return "[]";
            } finally {
                if (c != null) c.close();
            }
            JSONArray arr = new JSONArray();
            for (JSONObject o : map.values()) arr.put(o);
            return arr.toString();
        }

        // bank messages from the chosen senders only (an empty list means every bank sender)
        @JavascriptInterface
        public String readBankSmsFrom(int maxCount, String addressesJson) {
            java.util.Set<String> wanted = new java.util.HashSet<>();
            try {
                JSONArray a = new JSONArray(addressesJson == null ? "[]" : addressesJson);
                for (int k = 0; k < a.length(); k++) wanted.add(a.getString(k));
            } catch (Exception ignored) {
            }
            JSONArray arr = new JSONArray();
            Cursor c = null;
            try {
                c = getContentResolver().query(Uri.parse("content://sms/inbox"),
                        new String[]{"address", "body", "date"}, null, null, "date DESC");
                if (c == null) return "[]";
                int n = 0;
                while (c.moveToNext() && n < maxCount) {
                    String addr = c.getString(0);
                    String body = c.getString(1);
                    long date = c.getLong(2);
                    if (body == null || !body.contains("ریال") || !body.contains("موجودی")) continue;
                    if (!wanted.isEmpty() && (addr == null || !wanted.contains(addr))) continue;
                    JSONObject o = new JSONObject();
                    o.put("body", body);
                    o.put("date", date);
                    o.put("address", addr == null ? "" : addr);
                    arr.put(o);
                    n++;
                }
            } catch (Exception e) {
                return "[]";
            } finally {
                if (c != null) c.close();
            }
            return arr.toString();
        }

        @JavascriptInterface
        public String readBankSmsJson(int maxCount) {
            JSONArray arr = new JSONArray();
            Cursor c = null;
            try {
                c = getContentResolver().query(Uri.parse("content://sms/inbox"),
                        new String[]{"body", "date"}, null, null, "date DESC");
                if (c == null) return "[]";
                int n = 0;
                while (c.moveToNext() && n < maxCount) {
                    String body = c.getString(0);
                    long date = c.getLong(1);
                    if (body != null && body.contains("ریال") && body.contains("موجودی")) {
                        JSONObject o = new JSONObject();
                        o.put("body", body);
                        o.put("date", date);
                        arr.put(o);
                        n++;
                    }
                }
            } catch (Exception e) {
                return "[]";
            } finally {
                if (c != null) c.close();
            }
            return arr.toString();
        }
    }
}
